package com.example.webview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private lateinit var textView: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var personalKey = intent.getStringExtra("PersonalKey")
        textView = findViewById(R.id.textView)
        textView.text = personalKey

        // 추가
        var myWebView: WebView = findViewById(R.id.webview)
        myWebView.webViewClient = WebViewClient()
        myWebView.loadUrl("https://www.google.co.kr/maps/?hl=en/")
        myWebView.settings.javaScriptEnabled = true

    }
}